import pygame
import random 

# Générer une classe qui gère la notion de l'ennemie le plus redouté
class Yellow(pygame.sprite.Sprite):
    # Constructeur
    def __init__(self, event, game):
        super().__init__()
        self.image = pygame.image.load('assets/pictures/monstersyellow.png')
        self.rect = self.image.get_rect()
        self.rect.x = 600 + random.randint(100, 1000)
        self.rect.y = 282
        self.divise = 50000000000
        self.velocity = random.random() / self.divise
        self.lifemax = 200
        self.life = self.lifemax
        self.game = game
        self.event = event
        self.attack = 10
    
    
    # Provoque la perte de la vie du monstre jaune
    def dommageMonstreY(self, montant):
        self.life -= montant
        
        if self.life <= 0:
            self.game.toutYellow.remove(self)
         
    
    # Affiche la santé courante du monstre jaune   
    def sante(self, surface):
        # La couleur pour la jauge de vie (rouge pour le monstre)
        color = (255, 241, 51)
        # La couleur de l'arrière plan
        colorback = (128, 128, 128)
        
        # La position de la jauge de vie
        # La largeur de la jauge de vie
        # L'épaisseur de la jauge de vie
        position = [self.rect.x, self.rect.y, self.life, 7]
        positionback = [self.rect.x, self.rect.y, self.lifemax, 7]
        
        # Dessiner la barre
        pygame.draw.rect(surface, colorback, positionback) 
        pygame.draw.rect(surface, color, position)


    # Déplacement du monstre
    def avancer(self):
        if not self.game.boom(self, self.game.toutMakicia):
            self.rect.x -= self.velocity / 500000
        else:
            self.game.player.dommageMakicia(self.attack)
            
    